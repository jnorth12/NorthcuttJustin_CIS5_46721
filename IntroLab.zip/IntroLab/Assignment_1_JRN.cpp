/* 
 * File:   Assignment_1_JRN.cpp
 * Author: Justin Northcutt
 *
 * Created on June 22, 2020, 1:34 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    cout << "Hello world!" << endl;
    return 0;
}